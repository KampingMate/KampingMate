package com.demo.dto;

public class LeaveRoomRequest {
	 private int roomId;

	 public LeaveRoomRequest() {
	    }
	 
	    public int getRoomId() {
	        return roomId;
	    }

	    public void setRoomId(int roomId) {
	        this.roomId = roomId;
	    }
}
