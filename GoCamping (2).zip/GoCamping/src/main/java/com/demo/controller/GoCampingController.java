package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.demo.dto.CampingItem;
import com.demo.service.GoCampingAPI;

@Controller
public class GoCampingController {

    @Autowired
    private GoCampingAPI goCampingAPI;

    @GetMapping("/campingSites")
    public String getCampingSites(@RequestParam(defaultValue = "1") int page, Model model) {
        try {
            GoCampingAPI.CampingApiResponse response = goCampingAPI.getCampingSites(page, 10);
            List<CampingItem> campingItems = response.getItems();
            int totalCount = response.getTotalCount();

            int itemsPerPage = 10;
            int startIndex = (page - 1) * itemsPerPage;
            int endIndex = Math.min(startIndex + itemsPerPage, totalCount);

            model.addAttribute("totalCount", totalCount);
            model.addAttribute("items", campingItems);
            model.addAttribute("currentPage", page);
            model.addAttribute("hasPrev", page > 1);
            model.addAttribute("hasNext", endIndex < totalCount);
            model.addAttribute("startPage", Math.max(1, page - 5));
            model.addAttribute("endPage", Math.min((totalCount + itemsPerPage - 1) / itemsPerPage, page + 5));

            return "campingSites";
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("error", "Failed to load camping sites.");
            return "error";
        }
    }
}
