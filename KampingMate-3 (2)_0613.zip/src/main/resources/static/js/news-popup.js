// news-popup.js

let currentNewsIndex = 0;
const newsItems = document.querySelectorAll('.news-item');

function openNewsPopup() {
    document.getElementById('newsPopup').style.display = 'block';
    showCurrentNews();
}

function closeNewsPopup() {
    document.getElementById('newsPopup').style.display = 'none';
}

function showCurrentNews() {
    newsItems.forEach((item, index) => {
        if (index === currentNewsIndex) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}

function showPreviousNews() {
    if (currentNewsIndex > 0) {
        currentNewsIndex--;
        showCurrentNews();
    }
}

function showNextNews() {
    if (currentNewsIndex < newsItems.length - 1) {
        currentNewsIndex++;
        showCurrentNews();
    }
}
