package com.demo.dto;

public class DeleteRoomRequest {
	 private int roomId;

	    public DeleteRoomRequest() {
	    }

	    public int getRoomId() {
	        return roomId;
	    }

	    public void setRoomId(int roomId) {
	        this.roomId = roomId;
	    }
}
