package com.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

@Controller
public class ScheduleController {

    private static final String API_URL = "http://www.chungnam.go.kr/cnbbs/openApiMainFxList.do";
    private static final int NUM_OF_ROWS = 10;
    private static final int PAGE_NO = 1;

    @Autowired
    private RestTemplate restTemplate;

    @GetMapping("/schedule")
    public String getSchedule(Model model) {
        try {
            // API 요청을 위한 URL 생성
            String requestUrl = buildApiRequestUrl(API_URL, NUM_OF_ROWS, PAGE_NO);

            // REST API 호출
            ResponseEntity<String> response = restTemplate.getForEntity(requestUrl, String.class);

            // 결과를 모델에 담아서 뷰로 전달
            model.addAttribute("apiResponse", response.getBody());
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            // 예외 처리 - 페이지나 에러 메시지를 반환할 수 있음
            return "errorPage";
        }

        // 뷰 이름 반환 (schedule.html 등)
        return "customer_service/schedule";
    }

    // API 요청 URL을 생성하는 메서드
    private String buildApiRequestUrl(String apiUrl, int numOfRows, int pageNo) throws UnsupportedEncodingException {
        return UriComponentsBuilder.fromUriString(apiUrl)
                .queryParam("numOfRows", numOfRows)
                .queryParam("pageNo", pageNo)
                .build()
                .toUriString();
    }
}
