package com.demo.helper.constants;

public enum SocialLoginType {
    GOOGLE,
    FACEBOOK,
    KAKAO,
    NAVER
}
