package org.project.oauth.controller;

import java.util.Map;

import org.project.oauth.helper.constants.SocialLoginType;
import org.project.oauth.model.GoogleUser;
import org.project.oauth.service.OauthService;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@RequiredArgsConstructor
@Slf4j
public class OauthController {

    private final OauthService oauthService;

    private String refreshToken;
    private String accessToken;

    @GetMapping("/auth/login")
    public String login() {
        return "login";
    }

    @GetMapping(value = "/auth/{socialLoginType}")
    public String socialLoginType(
            @PathVariable(name = "socialLoginType") SocialLoginType socialLoginType,
            HttpServletResponse response) {
        log.info(">> 사용자로부터 SNS 로그인 요청을 받음 :: {} Social Login", socialLoginType);
        return oauthService.request(socialLoginType, response);
    }

    @PostMapping(value = "/auth/{socialLoginType}/callback")
    public String callback(
            @PathVariable(name = "socialLoginType") SocialLoginType socialLoginType,
            @RequestParam Map<String, String> params,
            Model model) {
        log.info(">> 소셜 로그인 API 서버로부터 받은 사용자 정보 :: {}", params);
        accessToken = params.get("access_token"); // access_token이 포함되어 있는지 확인 필요
        refreshToken = params.get("refresh_token"); // refresh_token이 포함되어 있는지 확인 필요
        GoogleUser user = new GoogleUser();
        user.setId(params.get("id"));
        user.setName(params.get("username"));
        user.setEmail(params.get("email"));
        user.setPicture(params.get("img"));
        model.addAttribute("user", user);
        return "userProfile";
    }

    @GetMapping("/auth/google/userinfo")
    public String getUserInfo(@RequestParam("accessToken") String accessToken) {
        return "Access Token: " + accessToken;
    }

    @RequestMapping("/callback")
    public ResponseEntity<String> handleCallback() {
        try {
            return getGoogleUserInfo();
        } catch (HttpClientErrorException e) {
            if (e.getStatusCode() == HttpStatus.UNAUTHORIZED) {
                accessToken = oauthService.refreshAccessToken(refreshToken);
                return getGoogleUserInfo();
            } else {
                throw e;
            }
        }
    }

    private ResponseEntity<String> getGoogleUserInfo() {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(accessToken);
        HttpEntity<String> entity = new HttpEntity<>(headers);
        return restTemplate.exchange("https://www.googleapis.com/oauth2/v1/userinfo", HttpMethod.GET, entity, String.class);
    }
}
