package org.project.oauth.helper.constants;

public enum SocialLoginType {
    GOOGLE,
    FACEBOOK,
    KAKAO,
    NAVER
}
