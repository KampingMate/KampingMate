package com.demo.dto;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

@JacksonXmlRootElement(localName = "CampingItem")
public class CampingItem {

    private String facltNm;
    private String lineIntro;
    private String mgcDiv;
    private String featureNm;
    private String addr1;
    private String addr2;
    private String tel;
    private String homepage;
    private String firstImageUrl;
    private String createdtime;
    private String modifiedtime;
    private String extshrCo;

    public CampingItem(String facltNm, String lineIntro, String mgcDiv, String featureNm, String addr1, String addr2, String tel, String homepage, String firstImageUrl, String createdtime, String modifiedtime, String extshrCo) {
        this.facltNm = facltNm;
        this.lineIntro = lineIntro;
        this.mgcDiv = mgcDiv;
        this.featureNm = featureNm;
        this.addr1 = addr1;
        this.addr2 = addr2;
        this.tel = tel;
        this.homepage = homepage;
        this.firstImageUrl = firstImageUrl;
        this.createdtime = createdtime;
        this.modifiedtime = modifiedtime;
        this.extshrCo = extshrCo;
    }

    // Getters and setters
    public String getFacltNm() {
        return facltNm;
    }

    public void setFacltNm(String facltNm) {
        this.facltNm = facltNm;
    }

    public String getLineIntro() {
        return lineIntro;
    }

    public void setLineIntro(String lineIntro) {
        this.lineIntro = lineIntro;
    }

    public String getMgcDiv() {
        return mgcDiv;
    }

    public void setMgcDiv(String mgcDiv) {
        this.mgcDiv = mgcDiv;
    }

    public String getFeatureNm() {
        return featureNm;
    }

    public void setFeatureNm(String featureNm) {
        this.featureNm = featureNm;
    }

    public String getAddr1() {
        return addr1;
    }

    public void setAddr1(String addr1) {
        this.addr1 = addr1;
    }

    public String getAddr2() {
        return addr2;
    }

    public void setAddr2(String addr2) {
        this.addr2 = addr2;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getHomepage() {
        return homepage;
    }

    public void setHomepage(String homepage) {
        this.homepage = homepage;
    }

    public String getFirstImageUrl() {
        return firstImageUrl;
    }

    public void setFirstImageUrl(String firstImageUrl) {
        this.firstImageUrl = firstImageUrl;
    }

    public String getCreatedtime() {
        return createdtime;
    }

    public void setCreatedtime(String createdtime) {
        this.createdtime = createdtime;
    }

    public String getModifiedtime() {
        return modifiedtime;
    }

    public void setModifiedtime(String modifiedtime) {
        this.modifiedtime = modifiedtime;
    }

    public String getExtshrCo() {
        return extshrCo;
    }

    public void setExtshrCo(String extshrCo) {
        this.extshrCo = extshrCo;
    }
}
