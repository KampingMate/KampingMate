package com.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.demo.domain.MemberData;
import com.demo.domain.User;
import com.demo.persistence.MemberRepository;
import com.demo.service.MemberService;
import com.demo.service.PasswordGenerator;

import jakarta.servlet.http.HttpSession;


@Controller
@RequestMapping("/oauth")
public class UserController {

	@Autowired
	MemberRepository memberRepo;
	
	@Autowired
	MemberService memberService;
	
	
    @PostMapping("/saveUserSession")
    @ResponseBody
    public String saveUserSession(@RequestBody User user, HttpSession session) {
        session.setAttribute("user", user);
        return "success";
    }

    @GetMapping("/contract")
    public String contractPage(HttpSession session, Model model) {
    	User user = (User) session.getAttribute("user");
        if (user != null) {
            String id = user.getId();
            
            int exists = memberService.confirmID(id);
            if(exists == 1) {
            	System.out.println("AutoLogin이동");
            	return "redirect:/oauth/autoLogin";
            }
            
        }
    	
        return "contract"; // templates/contract.html로 이동
    }
    
    @GetMapping("/login")
    public String loginPOSTNaver(HttpSession session) {
        
        return "callback";
    }
    
    @GetMapping("/joinForm")
    public String joinFormPage(HttpSession session, Model model) {
    	User user = (User) session.getAttribute("user");
        if (user != null) {
            model.addAttribute("email", user.getEmail());
            model.addAttribute("id", user.getId());
            model.addAttribute("provider", user.getProvider());
        }
        
         return "joinForm";
    }
    
    @PostMapping("/confirmEmail")
    @ResponseBody
    public int confirmEmail(@RequestParam String email) {
        return memberService.confirmEmail(email);
    }
    
    @PostMapping("/joinAction")
    public String joinAction(MemberData vo) {
    	MemberData member = new MemberData();
    	String randomPassword = PasswordGenerator.generateRandomPassword();
    	
    	member.setId(vo.getId());
    	member.setName(vo.getName());
    	member.setEmail(vo.getEmail());
    	member.setTelephone(vo.getTelephone());
    	member.setProvider(vo.getProvider());
    	member.setPassword(randomPassword);
    	
    	memberRepo.save(member);
    	
    	return "redirect:/";
    }
    
    @GetMapping("/autoLogin")
    public String autoLogin(HttpSession session) {
    	User user = (User) session.getAttribute("user");
        if (user != null) {
            String id = user.getId();
            
            MemberData loginUser = memberService.getMember(id);
            session.setAttribute("loginUser", loginUser);
            System.out.println("loginUser세션 등록");
           
        }
		return "redirect:/";
    }
}
